for i in xrange(3,101,1):
  print(i);
