#include "../template.h"
#include "KDTree.h"


int main() {
}

