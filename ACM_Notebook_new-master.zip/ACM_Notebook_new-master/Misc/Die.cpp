#include "../template.h"
#include "Die.h"
int main() {
}
