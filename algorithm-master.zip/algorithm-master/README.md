# C++ implementations of algorithms

These are my C++ implementations of algorithms,
which are written for studying/understanding algorithms.

These codes are published in **public domain.**
You can use the codes for *any purpose without any warranty*.


author: Takanori MAEHARA (web: http://www.prefield.com, e-mail: maehara@prefield.com, twitter: @tmaehara)

# Recruiting

I am a researcher at *RIKEN Center for Advanced Intelligence Project*, which is a Japanese governmental academic research institute. I am working on discrete algorithms (including topics in this github repository). We are hiring *strong programmers* who has some achievements in some competitions. If you are interested in, please feel free to contact me.
